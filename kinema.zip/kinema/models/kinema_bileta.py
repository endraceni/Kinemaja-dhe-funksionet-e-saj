from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError, UserError
from odoo.modules.module import get_module_resource


class Salla (models.Model):
    _name = "salla.salla"
    _description = "Informacion mbi sallat"

    name = fields.Char(string = "Emri Salles", required = True)
    kapaciteti = fields.Integer(string = "Kapaciteti", required = True)
    info_shtese = fields.Text(string = "Informacion Shtese")
    state = fields.Selection([('e lire','e Lire'),('e zene','e Zene')],default = "e lire")


class Shfaqje(models.Model):
    _name = "shfaqje.filmi"
    _description = "Informacion mbi shfaqjen"

    name = fields.Char(string = "Titulli i shfaqjes", required = True, ondelete ="cascade")
    id_salla = fields.Many2one('salla.salla', string = "Salla")
    id_film = fields.Many2one('film.film', string = "Filmi")
    ora_fillimit = fields.Datetime(string = "Orari Fillimit",required = True)
    ora_perfundimit = fields.Datetime(string = "Orari perfundimit",required = True)
    state = fields.Selection([('aktive','Aktive'),('draft','Draft'),('anulluar','Anulluar'),('perfunduar','Perfunduar')],default = "draft")
    bileta_id = fields.One2many('bileta.bileta', 'shfaqje_id', string = "Bileta")

    #Gjenero Bileta
    @api.multi
    def gjenero_bileta(self):
        for shfaqje in self:
            if shfaqje.id_salla:
                if shfaqje.id_salla.kapaciteti:
                    for r in range(0, shfaqje.id_salla.kapaciteti):
                        self.env['bileta.bileta'].create({'serial_no': r, 'shfaqje_id': shfaqje.id})

    @api.multi
    def cancel_show(self):
        for shfaqje in self:
                if shfaqje.id_salla.kapaciteti:
                    self.env['bileta.bileta'].search([('shfaqje_id', '=', shfaqje.id)]).unlink()

    @api.one
    def aktive(self):
        self.state = 'aktive'
        self.gjenero_bileta()


    @api.one
    def draft(self):
        return self.write({'state': 'draft'})

    @api.one
    def anulluar(self):
        self.state = 'anulluar'
        self.cancel_show()

    @api.one
    def perfunduar(self):
        self.state = 'perfunduar'
        for bileta in self:
            if bileta.bileta_id:
                self.bileta_id.write({'state':'perfunduar'})

    @api.constrains('id_salla.state')
    def raise_error(self):
        for salla in self:
            if salla.id_salla:
                if salla.id_salla.state  == "e zene":
                    raise UserError("Salla eshte e zene")
                else:
                    salla.id_salla = self.id_salla
                    salla.id_salla.state = "e zene"



class Bileta(models.Model):
    _name = "bileta.bileta"
    _description = "Bileta"

    serial_no = fields.Char(string = "Nr. Serial")
    shfaqje_id = fields.Many2one('shfaqje.filmi', string = "Shfaqje")
    state = fields.Selection([('free','Free'),('rezervuar','Rezervuar'),('konfirmuar','Konfirmuar'),('anulluar','Anulluar'),('perfunduar','Perfunduar')],default = 'free')



class Rezervim(models.Model):
    _name = "rezervim.filmi"
    _description = "Rezervimi Biletes"

    #name = fields.Char(string = "Nr.Rezervimi")
    shfaqje_id = fields.Many2one('shfaqje.filmi', string = "Shfaqje")
    orar_fillimi = fields.Datetime(related='shfaqje_id.ora_fillimit', string = "Orari Shfaqjes", readonly = True)
    #orar_perfundimii = fields.Datetime(related='shfaqje_id.ora_perfundimit', string="Orari i perfundimit Shfaqjes", readonly=True)
    state = fields.Selection([('regjistruar','Regjistruar'),('rezervuar','Rezervuar'),('konfirmuar','Konfirmuar'),('anulluar','Anulluar')], default = "regjistruar")

    emer_rezervimi = fields.Char(string="Nr.Rezervimi",readonly=True)
    orar_perfundimit = fields.Datetime(related='shfaqje_id.ora_perfundimit', string="Orari i perfundimit Shfaqjes", readonly=True)
    afati_anullimit = fields.Integer(string='Afati i anullimit')

    sequence_id = fields.Char('Sequence', readonly=True)

    @api.model
    def create(self, vals):
        seq = self.env['ir.sequence'].next_by_code('rezervim.filmi') or '/'
        vals['emer_rezervimi'] = seq
        return super(Rezervim, self).create(vals)

