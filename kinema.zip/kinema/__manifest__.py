{
    'name': 'Kinema',
    'version': '1.1',
    'category': 'Entertainment',
    'sequence': 75,
    'summary': 'Kinemaja dhe funksionet e saj',
    'description': "",
    'website': 'https://www.commprog.com',
    'images': [
    ],
    'depends': [
    ],
    'data': [
        'views/kinemaview.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'qweb': [],
}